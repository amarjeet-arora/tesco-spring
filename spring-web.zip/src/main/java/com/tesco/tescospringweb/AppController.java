package com.tesco.tescospringweb;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/mainapp")
public class AppController {
	@RequestMapping(path="/welcome",method = RequestMethod.GET)
	@ResponseBody
	public String sayWelcome() {
		return "welcome to spring app";
	}
	@RequestMapping(path="/login",method = RequestMethod.GET)
	
	public String login() {
		return "login";
	}
	
     @RequestMapping(path="/login",method = RequestMethod.POST)
	@ResponseBody
	public String loginUser(@RequestParam("uname")String uname,@RequestParam("pass")String pass) {
    	 if(uname.equals("admin") && pass.equals("manager")) {
    		 return "Login Success..!";
    	 }
		return "login failure...!";
	}
	
	
	
	@RequestMapping(path="/register",method = RequestMethod.GET)
	@ResponseBody
	public String registration() {
		return "welcome to register app";
	}
	

}
