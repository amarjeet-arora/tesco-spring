package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
@Service(value = "service")
public class Bankingservice {
	
	@Autowired
	@Qualifier(value = "sa")
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}
	
	public double calculate(double amount)
	{
		return ic.calculate(amount);
	}
	public void init() {
		System.out.println("Service bean initialize...!");
	}
	public void destroy() {
		System.out.println("Service bean destroyed...!");
	}

}
