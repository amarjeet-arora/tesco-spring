package com.example.tescospringcore;

 import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.Bankingservice;

 
public class TescoSpringCoreApplication {

	public static void main(String[] args) {
		 
	ConfigurableApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
 	Bankingservice bs= (Bankingservice)ctx.getBean("service");
	
	System.out.println(bs.hashCode());
 
	
	
	}

}
