package com.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.model.Employee;
@Repository
public class EmployeeDaoImpl extends JdbcDaoSupport implements EmployeeDAO{
	
	@Autowired
	//private DataSource dataSource;
	private AppDao dao;
	
	 

	@Override
	public void insertEmployee(Employee e) {
		dao.save(e);
	 
		
	}

	@Override
	public List<Employee> loadAll() {
		 String sql="select * from employee";
		 List<Employee> data= getJdbcTemplate().query(sql, new BeanPropertyRowMapper(Employee.class));
		return data;
	}

}
