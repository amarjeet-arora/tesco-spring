package com.client;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Users;
import com.sf.AppConfig;

public class Client {
	public static void main(String[] args) {
		// create the session from SF
		Session session= AppConfig.getSession();
		
		//start the transaction from given session
		
		Transaction tx= session.beginTransaction();
		
		Users users= new Users("usernew", "chennai");
		
		session.save(users);
		//session.evict(users);
		session.clear();
		Users usr= (Users) session.load(Users.class,1);
		System.out.println(usr);
		
		
		
		 
		
		 
		
		
	}

}
