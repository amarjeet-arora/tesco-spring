package adapterdemo;

public interface AcmeInterface {
	
	public void setFirstName(String f);
	public void setLastName(String l);
	
	public String getFirstName();
	public String getLastName();

}
