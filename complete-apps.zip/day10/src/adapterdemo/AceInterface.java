package adapterdemo;

public interface AceInterface {

	public void setName(String n);
	public String getName();
}
