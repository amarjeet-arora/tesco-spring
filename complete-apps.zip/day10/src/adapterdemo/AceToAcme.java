package adapterdemo;

public class AceToAcme  implements AcmeInterface{
	
	AceClass aceClass;
	
	String firstName;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	String lastName;
	public AceToAcme(AceClass aceClass) {
		 
		this.aceClass = aceClass;
		firstName= aceClass.getName().split(" ")[0];
		lastName= aceClass.getName().split(" ")[1];
	}
	

}
