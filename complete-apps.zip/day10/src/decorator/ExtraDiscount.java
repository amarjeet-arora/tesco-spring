package decorator;

public class ExtraDiscount extends SaleDecorator{
	
	Sale sale;

	public ExtraDiscount(Sale sale) {
		super();
		this.sale = sale;
	}

	@Override
	public double getTotal() {
		if(sale.getNop() >10)
			return sale.getTotal()-10;
			return sale.getTotal();
	}
public int getNop() {
	return sale.getNop();
}
}
