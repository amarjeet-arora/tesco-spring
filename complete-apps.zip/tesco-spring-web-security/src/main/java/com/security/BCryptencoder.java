package com.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCryptencoder {
	
	public static void main(String[] args) {
		BCryptPasswordEncoder bpe= new BCryptPasswordEncoder();
		System.out.println(bpe.encode("manager123"));
	}

}
