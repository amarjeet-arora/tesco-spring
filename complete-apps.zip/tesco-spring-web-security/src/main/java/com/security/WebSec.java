package com.security;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

//@Configuration
//@EnableWebSecurity
public class WebSec {
	
	/*
	 * @Bean public InMemoryUserDetailsManager detailsManager() {
	 * 
	 * List<UserDetails> users= new ArrayList<UserDetails>(); List<GrantedAuthority>
	 * adminauth= new ArrayList<GrantedAuthority>(); adminauth.add(new
	 * SimpleGrantedAuthority("ADMIN")); UserDetails admin= new
	 * User("admin","{noop}admin123",adminauth); users.add(admin);
	 * 
	 * 
	 * List<GrantedAuthority> managerauth= new ArrayList<GrantedAuthority>();
	 * managerauth.add(new SimpleGrantedAuthority("MANAGER")); UserDetails manager=
	 * new User("manager","{noop}manager123",managerauth); users.add(manager);
	 * 
	 * 
	 * List<GrantedAuthority> empauth= new ArrayList<GrantedAuthority>();
	 * empauth.add(new SimpleGrantedAuthority("EMP")); UserDetails emp= new
	 * User("employee","{noop}emp123",empauth); users.add(emp);
	 * 
	 * return new InMemoryUserDetailsManager(users); }
	 */
	
	@Autowired
	private DataSource dataSource;
	@Autowired
	private BCryptPasswordEncoder bce;
	@Bean
	public UserDetailsManager authenticateUsers() {
		UserDetails user= User.withUsername("admin").
				password(PasswordEncoderFactories.createDelegatingPasswordEncoder().encode("admin123")).build();
		JdbcUserDetailsManager users= new JdbcUserDetailsManager(dataSource);
		users.setAuthoritiesByUsernameQuery("select user_name,user_pwd,user_enabled from tescousers where user_name=?");
		users.setUsersByUsernameQuery("select user_name,user_role from tescousers where user_name=?");
		users.createUser(user);
		return users;
	}
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		http.authorizeRequests()
		 .antMatchers("/home").permitAll()
		 .antMatchers("/welcome").authenticated()
		 .antMatchers("/admin").hasAuthority("ADMIN")
		 .antMatchers("/emp").hasAuthority("EMP")
		 .antMatchers("/mgr").hasAuthority("MANAGER")
		 .antMatchers("/common").hasAnyAuthority("EMPLOYEE","MANAGER")
		 .anyRequest().authenticated()
		 .and()
		 .formLogin()
		 .defaultSuccessUrl("/welcome",true)
		 .and()
		 .logout()
		 .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
		 .and()
		 .exceptionHandling()
		 .accessDeniedPage("/accessdenied");
		return http.build();
	}
	
	

}
