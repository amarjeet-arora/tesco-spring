package defaultapp;

public interface InterOne {
public void add();
public default void show() {
	System.out.println("demo");
}
}
