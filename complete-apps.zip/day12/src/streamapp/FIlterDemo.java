package streamapp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FIlterDemo {
public static void main(String[] args) {
	List<String> al= new ArrayList<String>();
	al.add("Amitabh");
	al.add("Aman");
	al.add("Rahul");
	al.add("Shekhar");
	al.add("Yana");
	al.add("Lokesh");
	al.add("Sid");
	
	// al.stream().filter((s) -> s.startsWith("A")).sorted().map(String::toUpperCase).forEach(System.out::println);
	List<String> data =al.stream().sorted().map(String::toUpperCase).collect(Collectors.toList());
	
	System.out.println(data);
	

	
}
}
