package staticdemo;

public class StaticMain {
	public static void main(String[] args) {
		StaticDemo sd= new StaticDemo();
		StaticDemo.showData();
	}

}
