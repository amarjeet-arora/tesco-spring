package innerdemo;

public class InnerMain {
public static void main(String[] args) {
	InnerClassDemo ic= new InnerClassDemo();
	InnerClassDemo ic2= new InnerClassDemo("Admin");
	//System.out.println(ic2);
	ic.printEven();
}
}
