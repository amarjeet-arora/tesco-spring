package com.app.calc;

public class Calculator {
	
	public int addTrack(int a, int b) {
		return a+b;
	}

}
