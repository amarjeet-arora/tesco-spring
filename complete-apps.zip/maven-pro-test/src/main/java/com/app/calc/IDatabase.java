package com.app.calc;

public interface IDatabase {
public void updateScore(String studentId,int total);
}
