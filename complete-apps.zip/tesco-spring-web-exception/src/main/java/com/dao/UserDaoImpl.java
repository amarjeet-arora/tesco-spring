package com.dao;

import org.springframework.stereotype.Repository;

import com.model.User;
import com.model.Users;

@Repository
public class UserDaoImpl implements UserDao {
	private static Users list = new Users();
	static {
		list.getUserList().add(new User(1, "admin", "pass@123", "chennai", "admin@mail.com"));
		list.getUserList().add(new User(2, "alex", "alex@123", "NY", "alex@mail.com"));

		list.getUserList().add(new User(3, "david", "david@123", "blr", "david@mail.com"));

	}

	@Override
	public Users getAllUsers() {

		return list;
	}

	@Override
	public void addUser(User user) {
		list.getUserList().add(user);

	}

}
