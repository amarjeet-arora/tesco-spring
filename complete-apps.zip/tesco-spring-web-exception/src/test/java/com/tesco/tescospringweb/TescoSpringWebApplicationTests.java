package com.tesco.tescospringweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TescoSpringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
