package optionaldemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WithoutOptional {
	public static void main(String[] args) {
		List<Employee> emplist= createEmployee();
		
	Optional<Employee> emp= searchEmployee(emplist,"john");
	
	Employee e1= emp.orElse(new Employee("dummy", 0));
	//Employee e1= emp.orElseThrow(()-> new RuntimeException("Sorry,not found"));
	System.out.println(e1);
	
	if(emp.isPresent()) {
		Employee em= emp.get();
		System.out.println("Employee Name  "+ em.getName());
	}else {
		System.out.println("Sorry employee not found...");
	}
		
	}
	
	public static Optional<Employee> searchEmployee(List<Employee> emplist,String name) {
		
		for(Employee e: emplist) {
			if(e.getName().equalsIgnoreCase(name)) {
				return Optional.of(e);
			}
		}
		return Optional.empty();
	}
	
	public static List<Employee> createEmployee(){
		List<Employee> al= new ArrayList<Employee>();
		
		al.add(new Employee("john", 21));
		al.add(new Employee("Martin", 22));
		al.add(new Employee("Mary", 23));
		al.add(new Employee("Stephen", 25));
		al.add(new Employee("Gary", 23));
		
		return al;
	}

}
