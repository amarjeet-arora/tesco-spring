package collectiondemos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class HashMapWithList {
public static void main(String[] args) {
	HashMap<String, ArrayList<String>> map= new HashMap<String, ArrayList<String>>();
	
	map.put("USA", new ArrayList(Arrays.asList("Boston","NewYork","SF")));
	map.put("INDIA", new ArrayList(Arrays.asList("Mumbai","Chennai","Madurai")));
	map.put("UK", new ArrayList(Arrays.asList("London","Birmingham","Leicester")));
	
	for(Map.Entry<String, ArrayList<String>> entry : map.entrySet()) {
		System.out.println("Getting the List of Countries " +entry.getKey());
		for(String city: entry.getValue()) {
			System.out.println(city);
		}
	}
}
}
