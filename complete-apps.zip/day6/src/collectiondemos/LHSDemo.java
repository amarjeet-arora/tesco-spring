package collectiondemos;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LHSDemo {

	public static void main(String[] args) {
 Set<String> hs= new  LinkedHashSet<String>();
		 
		 hs.add("admin");
		 hs.add("manager");
		 hs.add("qa");
		 hs.add("admin");
		 
		 for(String data: hs) {
			 System.out.println(data);
		 }

	}

	}


