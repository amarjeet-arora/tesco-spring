package com.day1;

public class Welcome {
	
	public static void main(String[] args) {
		
		// empl object created
		Employee emp1= new Employee();
		Employee emp2= new Employee();
		emp1.setEmpId(Integer.parseInt(args[0]));
		emp1.setEmpName(args[1]);
		emp1.setCity(args[2]);
		
		System.out.println("Employee Details "+ emp1.getEmpName() + " "+ emp1.getCity());
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		
		
		emp2=emp1;
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		
	}

}
