package com.model;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SavingAccount implements InterestCalculator {

	private int duration;

	private double roi;

	@Override
	public double calculate(double amount) {

		return amount * roi / duration;
	}

}
