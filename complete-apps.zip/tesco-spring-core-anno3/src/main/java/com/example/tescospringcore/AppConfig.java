package com.example.tescospringcore;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.model.FDACalculator;
import com.model.SavingAccount;
import com.service.Bankingservice;

@Configuration
@ComponentScan("com")
public class AppConfig {
	@Bean
	@Lazy
	
	public FDACalculator fda() {
		return new FDACalculator(5, 5.6);
	}
	@Bean
	public SavingAccount sa() {
		return new SavingAccount(7, 7.8);
	}
	@Bean
	public Bankingservice service() {
		return new Bankingservice(fda());
	}

}
