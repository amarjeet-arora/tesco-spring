package com.service;

 
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.model.InterestCalculator;

import lombok.AllArgsConstructor;
@AllArgsConstructor
public class Bankingservice {
	
	 
	private InterestCalculator ic;

	 
	public double calculate(double amount)
	{
		return ic.calculate(amount);
	}
	@PostConstruct
	public void init() {
		System.out.println("Service bean initialize...!");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("Service bean destroyed...!");
	}

}
