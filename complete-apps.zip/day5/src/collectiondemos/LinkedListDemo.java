package collectiondemos;

import java.util.Collections;
import java.util.LinkedList;

public class LinkedListDemo {
public static void main(String[] args) {
	
	LinkedList<Employee> al= new LinkedList<Employee>();
	al.add(new Employee(103,"sohan", "delhi"));
	al.add(new Employee(107,"ram", "pune"));
	al.add(new Employee(101,"admin", "mumbai"));
	al.add(new Employee(102,"danis", "chennai"));
	al.add(new Employee(100,"reema", "kolkata"));
	al.add(new Employee(108,"esha", "lko"));
	
	al.addFirst(new Employee(1011,"esha2", "lko2"));
	Collections.sort(al,new NameComparator());
	
	
	for(Employee emp:al) {
		System.out.println(emp);
	}
}
}
