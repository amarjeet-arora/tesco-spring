package superdemo;

public class Manager extends Users{
	
	private String streetName;

	public Manager(String userName, String email, String city, String state, String streetName) {
		super(userName, email, city, state);
		 
		this.streetName = streetName;
	}
	
	

}
