package com.comp;

import java.util.Comparator;

import com.model.Users;

public class CityComp implements Comparator<Users>{

	@Override
	public int compare(Users o1, Users o2) {
		 
		return o1.getCity().compareTo(o2.getCity());
	}

}
