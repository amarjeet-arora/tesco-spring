package com.dao;

import org.springframework.stereotype.Component;

@Component(value = "wi")
public class WelcomeImpl implements Welcome{

	@Override
	public String sayWelcome(String name) {
		 System.out.println("inside method");
		return name + ", welcome to Spring AOP";
		 
	}

	@Override
	public void sayHi(String data) {
		 System.out.println("hi");
		
	}

}
