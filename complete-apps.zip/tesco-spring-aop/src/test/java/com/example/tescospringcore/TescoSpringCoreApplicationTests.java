package com.example.tescospringcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TescoSpringCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
