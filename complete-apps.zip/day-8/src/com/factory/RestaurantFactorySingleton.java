package com.factory;

import java.util.HashMap;
import java.util.Map;

import com.restaurant.IndianRestaurant;
import com.restaurant.ItalianReastaurant;
import com.restaurant.Restaurant;

public class RestaurantFactorySingleton {

	private static Map<String, Restaurant> maps;

	static {
		maps = new HashMap<String, Restaurant>();
		maps.put("i", new IndianRestaurant());
		maps.put("t", new ItalianReastaurant());
	}

	public static Restaurant create(String type) {

		System.out.println(maps.get(type));
		return maps.get(type);
	}

	private RestaurantFactorySingleton() {
	}
}
