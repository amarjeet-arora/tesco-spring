package com.client;

import com.factory.RestaurantFactory;
import com.factory.RestaurantFactorySingleton;
import com.restaurant.IndianRestaurant;
import com.restaurant.ItalianReastaurant;
import com.service.ServiceDesk;

public class RoomGuest {
	public static void main(String[] args) {
		
		 ServiceDesk desk= new ServiceDesk(RestaurantFactorySingleton.create("i"));
		
	     System.out.println(desk.takeOrderFromGuest("idli"));
	}
	
	
	

}
