package com.restaurant;

public class ItalianReastaurant implements Restaurant {

	@Override
	public String prepareFood(String dishName) {
		 
		return "Preparing " + dishName + "with olive oil and italian sauces.";
	}

}
