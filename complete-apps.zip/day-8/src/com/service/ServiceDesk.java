package com.service;

import com.restaurant.Restaurant;

public class ServiceDesk {
	
	private Restaurant restaurant;

	public ServiceDesk(Restaurant restaurant) {
		super();
		this.restaurant = restaurant;
	}
	
	public String takeOrderFromGuest(String dishName) {
		
		return restaurant.prepareFood(dishName);
	}

}
