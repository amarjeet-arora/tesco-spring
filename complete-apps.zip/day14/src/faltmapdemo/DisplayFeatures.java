package faltmapdemo;

public class DisplayFeatures {
	private String size;
	private MobileScreen mobileScreen;
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public MobileScreen getMobileScreen() {
		return mobileScreen;
	}
	public void setMobileScreen(MobileScreen mobileScreen) {
		this.mobileScreen = mobileScreen;
	}
	public DisplayFeatures(String size, MobileScreen mobileScreen) {
		super();
		this.size = size;
		this.mobileScreen = mobileScreen;
	}

}
