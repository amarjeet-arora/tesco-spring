package faltmapdemo;

public class Mobile {
	
	private long serialId;
	private String brandName;
	private String price;
	private DisplayFeatures displayFeatures;
	public long getSerialId() {
		return serialId;
	}
	public void setSerialId(long serialId) {
		this.serialId = serialId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public DisplayFeatures getDisplayFeatures() {
		return displayFeatures;
	}
	public void setDisplayFeatures(DisplayFeatures displayFeatures) {
		this.displayFeatures = displayFeatures;
	}
	public Mobile(long serialId, String brandName, String price, DisplayFeatures displayFeatures) {
		super();
		this.serialId = serialId;
		this.brandName = brandName;
		this.price = price;
		this.displayFeatures = displayFeatures;
	}

}
