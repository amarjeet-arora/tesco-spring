package sol;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

public class MobileMain {

	public static void main(String[] args) {
		 MobileScreen mobileScreen= new MobileScreen(340,1334);
		DisplayFeatures displayFeatures= new DisplayFeatures("4.7", Optional.of(mobileScreen));
		Mobile mobile= new Mobile(334456, "Apple", "4456", Optional.of(displayFeatures));
		MobileService mobileService= new MobileService();
		int width= mobileService.getMobileScreenWidth(Optional.of(mobile));
		System.out.println(width);

		
		
		Mobile mobile2= new Mobile(3344563, "Samsung", "4456", Optional.empty());
		int width2= mobileService.getMobileScreenWidth(Optional.of(mobile2));
		System.out.println(width2);
		
		LocalDate date=LocalDate.now().plusDays(3);
		System.out.println(date);
		LocalTime time=LocalTime.now();
		System.out.println(time);
	}
	

}
