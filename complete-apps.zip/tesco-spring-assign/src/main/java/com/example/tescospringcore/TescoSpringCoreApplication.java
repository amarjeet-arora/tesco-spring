package com.example.tescospringcore;

  
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Account;
import com.repo.AccountRepository;
import com.service.TransferService;

 
//@SpringBootApplication
public class TescoSpringCoreApplication {

	public static void main(String[] args) {
	 
	 
		 
	ConfigurableApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
	AccountRepository acr=(AccountRepository) ctx.getBean("ar");
		 
		 
	TransferService ts=(TransferService)ctx.getBean("ts");
	
	acr.add(new Account("a123", 1000));
	acr.add(new Account("b123", 100));
	
	System.out.println("Inital balance befor transfer in A123 " + acr.findById("a123").getBalance());
	
	System.out.println("Inital balance befor transfer in B123 " + acr.findById("b123").getBalance());
	
	System.out.println("Fund Transfer Initiated......!");
	
	ts.fundTransfer(200, "a123", "b123");
	
	
	
     System.out.println("Inital balance befor transfer in A123 " + acr.findById("a123").getBalance());
	
	System.out.println("Inital balance befor transfer in B123 " + acr.findById("b123").getBalance());
	
	ctx.close();
	}

}
