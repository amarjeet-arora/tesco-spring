package com.example.tescospringcore;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.repo.AccountRepoImpl;
import com.repo.AccountRepository;
import com.service.TransferServiceImpl;

@Configuration
@ComponentScan("com")
public class AppConfig {
	@Bean
	public AccountRepoImpl ar() {
		return new AccountRepoImpl();
	}
	@Bean
	public TransferServiceImpl ts() {
		return new TransferServiceImpl(ar());
	}

}
