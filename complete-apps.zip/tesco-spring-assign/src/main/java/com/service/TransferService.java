package com.service;

public interface TransferService {

	public void fundTransfer(double amount, String srcAcc,String destAcc);
}
