package com.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
// getter & setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Account {
private String accountNumber; 
private double balance;

public void debit(double amount) {
	balance -=amount;
}
public void credit(double amount) {
	balance +=amount;
}

public static Account copy(Account src) {
	return new Account(src.getAccountNumber(), src.getBalance());
}


}
