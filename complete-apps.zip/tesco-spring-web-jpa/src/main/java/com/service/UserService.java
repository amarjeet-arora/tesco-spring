package com.service;

import java.util.List;

import com.model.Users;

public interface UserService {
	
	
	public void addUser(Users users);
	public boolean loginUser(String uname,String pass);
	public List<Users> loadUsers();
	public boolean findUser(String uname);
	public boolean deleteUser(String uname);
	public void updateUser(String uname,Users user);

}
