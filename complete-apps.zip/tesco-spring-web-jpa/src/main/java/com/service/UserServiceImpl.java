package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDAO;
import com.model.Users;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDAO dao;
	List<Users> lst = new ArrayList<Users>();
	@Override
	public void addUser(Users users) {
	// lst.add(users);
		dao.save(users);
		
	}

	@Override
	public boolean loginUser(String uname, String pass) {
		if(uname.equals("admin")&& pass.equals("manager")) {
			return true;
		}
		return false;
	}

	@Override
	public List<Users> loadUsers() {
		 
		return (List<Users>)dao.findAll();
	}

	@Override
	public boolean findUser(String uname) {
		  Optional<Users> data= dao.findById(uname);
		  if(data.isPresent()) {
			  return true;
		  }
		  return false;
	}

	@Override
	public boolean deleteUser(String uname) {
		 Optional<Users> data= dao.findById(uname);
		  if(data.isPresent()) {
			  dao.deleteById(uname);
			  return true;
		  }
		  return false;
	}

	@Override
	public void updateUser(String uname,Users user) {
		 dao.updateUserByUserName(user.getPass(), user.getEmail(), user.getCity(),uname);
		
	}

}
