package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	
	@Autowired
	private UserService service;

	@PostMapping("/login")
	public String loginUser(@ModelAttribute Users users) {
		if (service.loginUser(users.getUname(), users.getPass())) {
			return "Login Success..!";
		}
		return "login failure...!";
	}

	@PostMapping("/register")
	public String registration(@ModelAttribute Users user) {
		 
		service.addUser(user);
		return "user registered";
	}
	@GetMapping("/loadall")
	public List<Users> loadAll(){
		return service.loadUsers();
	}
	@GetMapping("/finduser/{uname}")
	public String findUser(@PathVariable String uname) {
		if(service.findUser(uname)) {
			return uname + " found....!";
		}
		return "user not found..!";
	}
	
	@DeleteMapping("/deleteuser/{uname}")
	public String deleteUser(@PathVariable String uname) {
		if(service.deleteUser(uname)) {
			return uname + " found and deleted....!";
		}
		return "user not found..!";
	}
	@PutMapping("/updateuser/{uname}")
	public String updateUser(@PathVariable String uname,@RequestBody Users user) {
		 service.updateUser(uname, user); 
			return uname + " updated.!";
		 
	}

}
