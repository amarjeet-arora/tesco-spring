package com.aop;

 import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AppAdvice {
	@AfterThrowing(value = "* execution(* com.controller.*(..))",throwing = "ex")
	public void callAtException(JoinPoint jp,Exception ex) {
		
		System.out.println(ex.getMessage());
	}

}
