package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

 
import com.restaurant.IndianRestaurant;
import com.restaurant.ItalianReastaurant;
import com.service.ServiceDesk;

public class RoomGuest {
	public static void main(String[] args) {
		
		
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		
		 ServiceDesk desk= (ServiceDesk)ctx.getBean("rs");
		
	     System.out.println(desk.takeOrderFromGuest("idli"));
	}
	
	
	

}
