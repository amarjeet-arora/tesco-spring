package shopcart;

import java.util.ArrayList;

public class ShoppingCart {
private ArrayList<Product> al;


public ShoppingCart() {
	al= new ArrayList<Product>();
}
public void addItem(Product product) {
	al.add(product);
}

public int count() {
return al.size();	
}
public void empty() {
	al.clear();
}
public void removeItem(Product product) {
	al.remove(product);
}
}
