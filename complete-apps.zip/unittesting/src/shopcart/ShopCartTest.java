package shopcart;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class ShopCartTest {
	
	private ShoppingCart cart;
	
	 
	@Before
	public void setUp() {
		System.out.println("init begin");
		cart= new ShoppingCart();
		cart.addItem(new Product("book", 230));
		cart.addItem(new Product("pen", 130));
	}
    @Test
	public void testAdd() {
		cart.addItem(new Product("soap", 30));
		assertEquals(3, cart.count());
		
	}
    @Test
    public void testEmpty() {
    	cart.empty();
    	assertEquals(0, cart.count());
    }
}
