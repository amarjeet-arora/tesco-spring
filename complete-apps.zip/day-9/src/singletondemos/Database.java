package singletondemos;

public class Database {
	private static  Database db;
	private int record;
	private String name;

	private Database(int record, String name) {
		super();
		this.record = record;
		this.name = name;
	}

	private Database() {
		System.out.println("object ready..");

	}

	public static Database getInstance() {
		if (db == null) {
			System.out.println("no object found.... creating new..!");

			db = new Database();
		}
		return db;
	}

}
