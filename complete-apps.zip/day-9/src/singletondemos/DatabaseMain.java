package singletondemos;

public class DatabaseMain {
public static void main(String[] args) {
	
	Database db= Database.getInstance();
	
	System.out.println(db.hashCode());
	
    Database db2= Database.getInstance();
	
	System.out.println(db2.hashCode());
}
}
