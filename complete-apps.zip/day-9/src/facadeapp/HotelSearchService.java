package facadeapp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class HotelSearchService {
private List<Room> rooms;

public HotelSearchService() {
	 rooms= new ArrayList<Room>();
}
public void addRoom(Room room) {
	rooms.add(room);
}
public List<Room> search(RoomType roomType){
	LinkedList<Room> searchList= new  LinkedList<Room>();
	for(Room r: rooms) 
		if(r.isVacant() && r.getType().equals(roomType))
			searchList.add(r);
		return searchList;
	
}
public void reverveRoom(int rno) {
	for(Room r: rooms) {
		if(r.getRoomNo()==rno) {
			r.setVacant(false);
			return;
		}
	}
}

}
