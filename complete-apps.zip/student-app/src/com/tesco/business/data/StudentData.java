package com.tesco.business.data;

import java.util.Collections;

import com.tesco.frammework.data.ReportBodyData;

public class StudentData extends ReportBodyData {

	public static final int NAME = 1;
	public static final int TOTAL = 2;
	public static final String ASC = "A";
	public static final String DESC = "D";

	public StudentData() {
		StudentDAO dao = new StudentDAO();
		reportData = dao.fetchStudentData();
	}

	@Override
	public void sortData(int sortField, String sortOrder) {

		switch (sortField) {
		case 1:
			if (sortOrder.equals(ASC)) {
				NameAsc namesort = new NameAsc();
				Collections.sort(reportData, namesort);
			} else if (sortOrder.equals(DESC)) {
				Nammedesc namesort = new Nammedesc();
				Collections.sort(reportData, namesort);
			}

		case 2:
			if (sortOrder.equals(ASC)) {
				TotalComrareAsc namesort = new TotalComrareAsc();
				Collections.sort(reportData, namesort);
			} else if (sortOrder.equals(DESC)) {
				TotalCompareDesc namesort = new TotalCompareDesc();
				Collections.sort(reportData, namesort);
			}

		}
	}

}
