package com.tesco.business.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDAO {

	private Connection conn;
	private Statement statement;
	private static final String USER_NAME="root";
	private static final String PASSWORD="root";
	
	private static final String DRIVER="com.mysql.jdbc.Driver";
	private static final String DBURL="jdbc:mysql://localhost:3306/tescodb";
	
	public StudentDAO() {
		 try {
			Class.forName(DRIVER);
			conn=DriverManager.getConnection(DBURL,USER_NAME,PASSWORD);
			statement=conn.createStatement();
		 }catch (Exception e) { System.out.println(e);}
	}
	public ArrayList<Student> fetchStudentData(){
		ResultSet rs;
		ArrayList<Student> list= new ArrayList<Student>();
		Student stu;
		try {
			 
			
			rs=statement.executeQuery("select * from student_master");
		 
			 
			while(rs.next()) {
				stu= new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7));
				list.add(stu);
			}
		}catch (Exception e) {}
		return list;
	}
}
