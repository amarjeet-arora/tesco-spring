package com.tesco.business.data;

public class Student {
private int roolNo;
private String name;
private String gender;
private int maths;
private int physics;
private int chemistry;
private int cs;
public int getRoolNo() {
	return roolNo;
}
public void setRoolNo(int roolNo) {
	this.roolNo = roolNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public int getMaths() {
	return maths;
}
public void setMaths(int maths) {
	this.maths = maths;
}
public int getPhysics() {
	return physics;
}
public void setPhysics(int physics) {
	this.physics = physics;
}
public int getChemistry() {
	return chemistry;
}
public void setChemistry(int chemistry) {
	this.chemistry = chemistry;
}
public int getCs() {
	return cs;
}
public void setCs(int cs) {
	this.cs = cs;
}
public Student(int roolNo, String name, String gender, int maths, int physics, int chemistry, int cs) {
	super();
	this.roolNo = roolNo;
	this.name = name;
	this.gender = gender;
	this.maths = maths;
	this.physics = physics;
	this.chemistry = chemistry;
	this.cs = cs;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Student [roolNo=" + roolNo + ", name=" + name + ", gender=" + gender + ", maths=" + maths + ", physics="
			+ physics + ", chemistry=" + chemistry + ", cs=" + cs + "]";
}




}
