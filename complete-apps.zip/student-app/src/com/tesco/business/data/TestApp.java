package com.tesco.business.data;

import java.util.List;

public class TestApp {

	public static void main(String[] args) {
		 StudentDAO std= new StudentDAO();
		List<Student> lst= std.fetchStudentData();
		for(Student st: lst) {
			System.out.println(st);
		}
	}

}
