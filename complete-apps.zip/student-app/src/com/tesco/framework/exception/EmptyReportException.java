package com.tesco.framework.exception;

public class EmptyReportException extends Exception {
	
	
	public EmptyReportException() {
		 super();
	}
	public EmptyReportException(String exceptionID) {
		 super(exceptionID);
	}
}
