package com.tesco.framework.exception;

public class AppException extends Exception {
	
	private String exceptionID;

	public AppException() {
		this.exceptionID=null;
	}
	
	
	public AppException(String exceptionID) {
	this.exceptionID=exceptionID;
	}

}
