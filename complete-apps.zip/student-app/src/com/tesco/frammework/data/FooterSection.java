package com.tesco.frammework.data;

public class FooterSection {
	
	public String footerMSG="";

}
