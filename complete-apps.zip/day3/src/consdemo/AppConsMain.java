package consdemo;

public class AppConsMain {

	public static void main(String[] args) {
		 AppCons appCons= new AppCons();
		 
		 AppCons appCons2= new AppCons(101, "Arun", "HRMS");
		 
		 //System.out.println(appCons);
		 
		 System.out.println("=========");
		 
		 System.out.println(appCons2);

	}

}
