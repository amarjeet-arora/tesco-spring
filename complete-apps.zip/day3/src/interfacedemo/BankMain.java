package interfacedemo;

public class BankMain {

	public static void main(String[] args) {
		 SBI sbi= new SBI();
		System.out.println(sbi.checkBalance("a1234"));
		   sbi.purchaseShare();
		 CooperativeBank bank= new CooperativeBank();
		System.out.println(bank.depositAmount(345));

	}

}
