package interfacedemo;

public interface SEBI {
	
	public void purchaseShare();
	public void sellShares();

}
