package interfacedemo;

public interface RBI {
	public int checkBalance(String accNo);

	public int depositAmount(int amount);

	public int withdrawAmount(int amount);

}
