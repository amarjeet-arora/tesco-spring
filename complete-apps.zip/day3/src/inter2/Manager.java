package inter2;

public interface Manager extends Employee {
	
    void leadteam();
}
