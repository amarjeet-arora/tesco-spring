package inter2;

public interface Employee {
	
	public void joinCompany();
	public void takeLeaves();

}
