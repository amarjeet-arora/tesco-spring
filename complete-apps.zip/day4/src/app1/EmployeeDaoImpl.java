package app1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EmployeeDaoImpl implements EmployeeDAO{

	@Override
	public void addUser(Employee employee) throws GenericException {
		 
			try {
				FileOutputStream fos= new FileOutputStream("c://use/myuser");
			} catch (FileNotFoundException e) {
				 throw new GenericException("OOPS ...something went wrong, try after sometime..!", e);
				 
				 
			}
	 
			 
		
	}

}
