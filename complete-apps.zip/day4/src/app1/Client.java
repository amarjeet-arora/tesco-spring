package app1;

import java.io.FileNotFoundException;

public class Client {

	public static void main(String[] args) {
		 
		Employee e= new Employee("admin", "pune");
		EmployeeDAO ed= new EmployeeDaoImpl();
		
		 
			try {
				ed.addUser(e);
			} catch (GenericException e1) {
				System.out.println(e1.getMessage());

			 
			}
		 
			 
			 
		}

	}


