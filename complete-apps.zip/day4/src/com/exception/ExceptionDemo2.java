package com.exception;

public class ExceptionDemo2 {
	public static void main(String[] args) {
		
		int a=0;
		
		try {
			int first= Integer.parseInt(args[0]);
			int second= Integer.parseInt(args[1]);
			a= first/second;
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("please provide the value");
		}
		catch (ArithmeticException e) {
			System.out.println("please provide the correct value"); 
		}catch (Exception e) {
			System.out.println("call me when none can handle");
		}finally {
			System.out.println("call me everytime");
		}
	System.out.println(a);
	}
}
