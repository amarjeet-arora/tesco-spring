import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionApp {
	public static Connection conn ;
	public static PreparedStatement pst;

	public static void main(String[] args) {
		String ins = "insert into employee values(?,?,?)";

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
		}

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb", "root", "root");
			pst = conn.prepareStatement(ins);
			conn.setAutoCommit(false);

			pst.setString(1, "SAM");
			pst.setString(2, "chennai");
			pst.setString(3, "HRMS");

			pst.addBatch();

			pst.setString(1, "ADAM");
			pst.setString(2, "BLR");
			pst.setString(3, "Finance");

			pst.addBatch();

			pst.setString(1, "Shilpa");
			pst.setString(2, "Pune");
			pst.setString(3, "Banking");

			pst.addBatch();

			int totalCount[] = pst.executeBatch();
			if (totalCount.length > 0) {
				conn.commit();
				System.out.println("Data updated");
			}

		} catch (SQLException e) {
try {
	if(conn != null) {
		System.out.println("Rolling back....");
		conn.rollback();
	}
}catch(SQLException e2) {}
		}
	}
}
