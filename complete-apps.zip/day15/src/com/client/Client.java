package com.client;

import java.util.List;

import com.dao.EmployeeDao;
import com.dao.EmployeeDaoImpl;
import com.model.Employee;

public class Client {

	public static void main(String[] args) {
		
		Employee e= new Employee("Adam", "NY", "Banking");
		 
		EmployeeDao ed= new EmployeeDaoImpl();
		//ed.addEmployee(e);
		//System.out.println("Added");
		
		List<Employee> data= ed.loadEmployee();
		//System.out.println(data);
		for(Employee em:data) {
			//System.out.println(em);
		}

	Employee em=ed.findEmp("Adam");
	System.out.println(em);
		
	}

}
