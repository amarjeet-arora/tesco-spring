package com.model;

public class Employee {
private String empName;
private String empCity;
private String empProject;
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpCity() {
	return empCity;
}
public void setEmpCity(String empCity) {
	this.empCity = empCity;
}
public String getEmpProject() {
	return empProject;
}
public void setEmpProject(String empProject) {
	this.empProject = empProject;
}
public Employee(String empName, String empCity, String empProject) {
	super();
	this.empName = empName;
	this.empCity = empCity;
	this.empProject = empProject;
}
public Employee() {
	super();
	 
}


public Employee(String empCity, String empProject) {
	super();
	this.empCity = empCity;
	this.empProject = empProject;
}
@Override
public String toString() {
	return "Employee [empName=" + empName + ", empCity=" + empCity + ", empProject=" + empProject + "]";
}



}
