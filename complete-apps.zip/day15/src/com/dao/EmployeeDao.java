package com.dao;

import java.util.List;

import com.model.Employee;

public interface EmployeeDao {

	public void addEmployee(Employee employee);
	public List<Employee> loadEmployee();
	public Employee findEmp(String name);
	public void deleteEmp(String name);
	public void updateEmp(String name,Employee emp);
}
