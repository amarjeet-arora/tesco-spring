package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.connection.DbConnection;
import com.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Connection conn= DbConnection.getConnection();
	PreparedStatement pst;
	ResultSet rs;
	List<Employee> lst= new ArrayList<Employee>();

	@Override
	public void addEmployee(Employee employee) {
		try {
		String insertData="insert into employee values(?,?,?)";
		pst= conn.prepareStatement(insertData); 
		pst.setString(1, employee.getEmpName());
		pst.setString(2, employee.getEmpCity());
		pst.setString(3, employee.getEmpProject());
		pst.executeUpdate();
		}catch(Exception e) {}
	}

	@Override
	public List<Employee> loadEmployee() {
		try {
		 String query= "select * from employee";
	     pst= conn.prepareStatement(query); 
		 rs= pst.executeQuery();
		 while(rs.next()) {
			 lst.add(new Employee(rs.getString(1), rs.getString(2), rs.getString(3)));
		 }
		}catch(Exception e) {}
		return lst;
	}

	@Override
	public Employee findEmp(String name) {
		Employee data=null;
		try {
			 String query= "select * from employee where empname=?";
		     pst= conn.prepareStatement(query); 
		     pst.setString(1, name);
			 rs= pst.executeQuery();
			 while(rs.next()) {
			data= new Employee(rs.getString(1), rs.getString(2), rs.getString(3));
			 }
			}catch(Exception e) {}
			return data;
	}

	@Override
	public void deleteEmp(String name) {
		     try {
			 String query= "delete from employee where empname=?";
		     pst= conn.prepareStatement(query); 
		     pst.setString(1, name);
			 pst.executeUpdate();
			 
			}catch(Exception e) {}
			 
	}

	@Override
	public void updateEmp(String name,Employee emp) {
		 try {
			 String query= "update employee set empcity=? where empname=name ";
		     
			 
			}catch(Exception e) {}
			 
		
	}
	

}
