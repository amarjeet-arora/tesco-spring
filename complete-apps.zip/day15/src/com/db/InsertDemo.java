package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertDemo {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		String insertData="insert into employee values('admin','mumbai','hrms')";
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb","root","root");
		  
		 
		 Statement stmt= conn.createStatement();
		int data= stmt.executeUpdate(insertData);
		if(data >0) {
			System.out.println("user added");
		}
	}


}
