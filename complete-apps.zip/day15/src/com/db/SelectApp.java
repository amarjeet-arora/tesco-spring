package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

 
public class SelectApp {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		 String Query="select * from employee";
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb","root","root");
		 PreparedStatement stmt= conn.prepareStatement(Query);
		 ResultSet rs= stmt.executeQuery();
		 
		 while(rs.next()) {
			 System.out.println(rs.getString(1));
			 System.out.println(rs.getString(2));
			 System.out.println(rs.getString(3));
		 }
		 
		 
		  
	}

}
