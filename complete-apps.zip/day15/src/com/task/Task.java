package com.task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import com.model.Employee;

public class Task {
	public static Connection conn ;
	public static PreparedStatement pst;
	public static ResultSet rs;
	static HashMap<String, ArrayList<Employee>> hm=new HashMap<String, ArrayList<Employee>>();

	public static void main(String[] args) throws Exception{
		String query="select * from employee";
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb", "root", "root");
		
		pst= conn.prepareStatement(query);
		rs=pst.executeQuery();
		while(rs.next()) {
		 
			hm.put(rs.getString(1),new ArrayList(Arrays.asList(rs.getString(2),rs.getString(3))));
		}

	}





}
