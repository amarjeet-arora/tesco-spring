package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {

	static Connection conn;
	
	 public static Connection getConnection() {
		 try {
		 Class.forName("com.mysql.jdbc.Driver");
		 conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb","root","root");
		 
		}catch(Exception e) {}
		 return conn;
	 }
}
