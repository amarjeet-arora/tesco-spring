package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.InsuranceDao;
import com.model.Employee;
import com.model.Insurance;
@Service
public class EmpInsuranceImpl implements EpmInsurance{
	
	@Autowired
	private EmployeeService empService;
	@Autowired
	private InsuranceDao insDao;

	@Override
	@Transactional
	public void assignInsuranceToEmployee(Employee employee, Insurance insurance) {
		 
		empService.insertEmployee(employee);
		if(employee.getEmpName().equals("manoj1")) {
			throw new RuntimeException("something went wrong");
		}
		insDao.addInsurance(insurance);
	}

}
