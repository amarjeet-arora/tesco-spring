package com.service;

import com.model.Employee;
import com.model.Insurance;

public interface EpmInsurance {
public void assignInsuranceToEmployee(Employee employee,Insurance insurance);
}
