package com.example.tescospringcore;

  
 import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Employee;
import com.model.Insurance;
import com.service.EmployeeService;
import com.service.EpmInsurance;

 

 
@SpringBootApplication
@ComponentScan("com")
public class TescoSpringCoreApplication {

	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(TescoSpringCoreApplication.class, args);
		EpmInsurance service=(EpmInsurance)ctx.getBean(EpmInsurance.class);
		
		Employee emp= new Employee("manoj","mumbai", "HRMS");
		Insurance insurance= new Insurance("admin", "Indivisual", 10000);
		
		service.assignInsuranceToEmployee(emp, insurance);
		
	}

}
