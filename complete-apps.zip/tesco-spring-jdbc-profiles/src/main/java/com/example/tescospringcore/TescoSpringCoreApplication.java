package com.example.tescospringcore;

  
 import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;


 

 
@SpringBootApplication
@ComponentScan("com")
public class TescoSpringCoreApplication {

	public static void main(String[] args) {
	  SpringApplication.run(TescoSpringCoreApplication.class, args);
	 
		
 		
	}

}
