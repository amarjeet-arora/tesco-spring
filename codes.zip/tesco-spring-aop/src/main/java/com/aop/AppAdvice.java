package com.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
@Aspect
@Component
public class AppAdvice {

	@Before(" execution (* com.dao.Welcome.sayWelcome(..))")
	public void callBefore() {
		System.out.println("i am activated before method call..");
	}
	@Before(" execution (* com.dao.Welcome.sayHi(..))")
	public void callBeforeHi() {
		System.out.println("i am activated before method HI..");
	}
	@After(" execution (* com.dao.Welcome.*(..))")
	public void callAfterHi() {
		System.out.println("i am activated After method HI..");
	}
}
