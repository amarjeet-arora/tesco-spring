package adapterdemo;

// old API
public class AceClass implements AceInterface{

	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	 

}
