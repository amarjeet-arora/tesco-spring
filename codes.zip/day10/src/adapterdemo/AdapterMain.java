package adapterdemo;

public class AdapterMain {
public static void main(String[] args) {
	
	AceClass aceClass= new AceClass();
	aceClass.setName("Amarjeet Singh");
	
	AceToAcme aceToAcme= new AceToAcme(aceClass);
	
	System.out.println("User First Name "+ aceToAcme.getFirstName());
	System.out.println("User Last Name "+ aceToAcme.getLastName());
}
}
