package decorator;

public class Sale {
private int nop;
private double saleAmount;
public int getNop() {
	return nop;
}
public void setNop(int nop) {
	this.nop = nop;
}
public double getSaleAmount() {
	return saleAmount;
}
public void setSaleAmount(double saleAmount) {
	this.saleAmount = saleAmount;
}
public Sale(int nop, double saleAmount) {
	super();
	this.nop = nop;
	this.saleAmount = saleAmount;
}
@Override
public String toString() {
	return "Sale [nop=" + nop + ", saleAmount=" + saleAmount + "]";
}
public Sale() {
	super();
	 
}
 
public double getTotal() {
	return saleAmount;
}


}
