package decorator;

public abstract class SaleDecorator extends Sale{

	 public abstract double getTotal();

}
