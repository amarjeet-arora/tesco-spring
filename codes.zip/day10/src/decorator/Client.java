package decorator;

public class Client {

	public static void main(String[] args) {
		 Sale sale= new Sale(15, 2000.00);
		 sale= new ExtraDiscount(sale);
		 
		 //sale= new DiscountDecorator(sale);
		
		 System.out.println(sale.getTotal());

	}

}
