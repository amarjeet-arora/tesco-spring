package decorator;

public class DiscountDecorator extends SaleDecorator{

	Sale sale;
	@Override
	public double getTotal() {
		
		return sale.getTotal()-(5.0/100.00*sale.getTotal());
	}
	public DiscountDecorator(Sale sale) {
		super();
		this.sale = sale;
	}

	
}
