package com.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;

import com.comp.CityComp;
import com.model.Users;

public class AppMain {

	ArrayList<Users> al= new ArrayList<Users>();
	public static void main(String[] args) {
		new AppMain().showUsers();
		}
	// print the data
	void showUsers() {
		getUsers();
		Collections.sort(al,new CityComp());
		for(Users usr: al)
		System.out.println(usr);
	}
// load data from file and read it	
void getUsers() {
	try {
		File file= new File("userdata.txt");
		BufferedReader br= new BufferedReader(new FileReader(file));
		String line= null;
		while((line=br.readLine()) != null) {
		addSong(line);
		}
	}catch (Exception e) {}
		
	}
// split and take the data from getusers and counstruct the object and save it in collection
 void addSong(String linetoparse) {
	 String [] tokens= linetoparse.split("/");
	 Users users= new Users(tokens[0], tokens[1], tokens[2], tokens[3]);
	 al.add(users);
 }

}
