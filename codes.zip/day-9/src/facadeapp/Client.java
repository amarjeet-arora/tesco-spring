package facadeapp;

public class Client {

	public static void main(String[] args) {
		 
		HotelFacade facade= new HotelFacade();
		
		facade.displayAvailableRooms();

		System.out.println(facade.reserve(RoomType.DOUBLE));
		facade.displayAvailableRooms();
	}

}
