package facadeapp;

import java.util.List;

public class HotelFacade {
	
	HotelSearchService searchService;
	
 public	HotelFacade(){
		searchService= new HotelSearchService();
		for(int i=0;i<20;i++) {
			if(i%2 ==0) {
				searchService.addRoom(new Room(i+1, RoomType.SINGLE, true));
			}else {
				searchService.addRoom(new Room(i+1, RoomType.DOUBLE, true));
			}
		}
	}
	public String reserve(RoomType rt) {
		List<Room>r= searchService.search(rt);
		if(r.size() >0) {
			searchService.reverveRoom(r.get(0).getRoomNo());
			return "success";
		}
		else {
			return "failure";
		}
	}
	public void displayAvailableRooms() {
		System.out.println(searchService.search(RoomType.SINGLE));
		System.out.println(searchService.search(RoomType.DOUBLE));
	}

}
