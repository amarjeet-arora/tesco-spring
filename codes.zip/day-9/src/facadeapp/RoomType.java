package facadeapp;

public enum RoomType {
	
	SINGLE,DOUBLE;

}
