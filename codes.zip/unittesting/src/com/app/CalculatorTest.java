package com.app;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	@BeforeClass
	public static void callOnce() {
		System.out.println("called only in beg");
	}
	
	@AfterClass
	public static void callOnceEnd() {
		System.out.println("called only at end");
	}
	
	int a;
	@Before
	public void callBefore() {
	 a=10;
	 System.out.println(a);
	}
	@After
	public void callAfter() {
		System.out.println("called After...!");
	}
@Test
	public void inc() {
		System.out.println(++a);
	}
@Test
public void inc2() {
	System.out.println(++a);
}
	//@Test
	public void testCalculateAdd() {
	assertEquals(30, new Calculator().calculateAdd(10, 20));
	}

}
