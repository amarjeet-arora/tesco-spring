package com.app;

public class Calculator {
	public int calculateAdd(int a,int b) {
		return a+b;
	}

}
