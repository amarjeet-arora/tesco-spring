package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.model.Account;
import com.repo.AccountRepository;

public class TransferServiceImpl implements TransferService{
	
	private AccountRepository repo;
	
	public TransferServiceImpl(AccountRepository repo) {
		 this.repo=repo;
	}
	
	@Override
	public void fundTransfer(double amount, String srcAcc, String destAcc) {
		 Account srcAccount= repo.findById(srcAcc);
		 Account destAccount= repo.findById(destAcc);
		 
		 srcAccount.debit(amount);
		 destAccount.credit(amount);
		 
		 repo.update(srcAccount);
         repo.update(destAccount);		
	}
	@PostConstruct
	public void beginTran() {
		System.out.println("Initiated....!");
	}
	@PreDestroy
	public void endTransaction() {
		System.out.println("Transaction ends...!");
	}

}
