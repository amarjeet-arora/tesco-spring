package com.repo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.model.Account;

public class AccountRepoImpl  implements AccountRepository{
	
	
	Map<String, Account> accountById= new HashMap<String, Account>();
	
	@Override
	public Account findById(String accId) {
		 return Account.copy(accountById.get(accId));
	}

	@Override
	public void update(Account account) {
		 if(!accountById.containsKey(account.getAccountNumber())) 
			 throw new IllegalArgumentException("Account not found...!");
			 accountById.put(account.getAccountNumber(), Account.copy(account));
		 }

	@Override
	public void add(Account account) {
		if(accountById.containsKey(account.getAccountNumber())) 
			 throw new IllegalArgumentException("Account already Exist...!");
			 accountById.put(account.getAccountNumber(), Account.copy(account));
		
}

	@Override
	public Set<Account> findAll() {
		 HashSet<Account> allAccount= new HashSet<Account>();
		 for(Account account: accountById.values())
			 allAccount.add(Account.copy(account));
		 return allAccount;
	}

}
