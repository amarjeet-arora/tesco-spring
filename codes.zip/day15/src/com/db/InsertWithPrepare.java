package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 
 
public class InsertWithPrepare {
	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		String insertData="insert into employee values(?,?,?)";
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/tescodb","root","root");
		  
		 
		 PreparedStatement stmt= conn.prepareStatement(insertData);
		 stmt.setString(1, "sam");
		 stmt.setString(2, "mumbai");
		 stmt.setString(3, "Finance");
		int data= stmt.executeUpdate();
		if(data >0) {
			System.out.println("user added");
		}
	}


}
