package com.app.mock;

public interface AddService {
public int add(int a, int b);
}
