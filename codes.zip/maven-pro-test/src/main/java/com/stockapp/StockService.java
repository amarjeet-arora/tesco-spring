package com.stockapp;

public interface StockService {
	
	public double getPrice(Stock stock);

}
