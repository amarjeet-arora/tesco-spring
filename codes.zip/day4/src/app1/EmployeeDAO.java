package app1;

import java.io.FileNotFoundException;

public interface EmployeeDAO {
	public void addUser(Employee employee) throws GenericException;

}
