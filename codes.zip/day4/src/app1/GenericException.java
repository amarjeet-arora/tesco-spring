package app1;

public class GenericException extends Exception{

	public GenericException(String message, Throwable cause) {
		super(message, cause);
		 
	}
	
	
	

}
