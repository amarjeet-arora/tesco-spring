package app1;

public class Employee {
	
	private String name;
	private String city;
	public Employee(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", city=" + city + "]";
	}
	

}
