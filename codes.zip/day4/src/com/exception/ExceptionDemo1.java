package com.exception;

public class ExceptionDemo1 {
	public static void main(String[] args) {
		int a=0;
		try {
	      a=20/0;
		}catch(ArithmeticException e) {
			System.out.println("Give the correct Value....");
			
		}
		
		System.out.println(a);
	}
}
