package com.exception;

public class ExceptionDemo3 {
	
	public static void validateAge(int age) {
		if(age <18) {
			throw new ArithmeticException("You are not eligible to access");
		}
		else {
			System.out.println("welcome User....!");
		}
		System.out.println("called after");
	}
	
	public static void main(String[] args) {
		try {
		validateAge(20);
		}catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
