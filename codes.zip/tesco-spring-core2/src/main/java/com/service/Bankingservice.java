package com.service;

import com.model.InterestCalculator;

public class Bankingservice {
	
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}
	
	public double calculate(double amount)
	{
		return ic.calculate(amount);
	}

}
