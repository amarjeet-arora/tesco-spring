package com.example.tescospringcore;

 import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.Bankingservice;

//@SpringBootApplication
public class TescoSpringCoreApplication {

	public static void main(String[] args) {
		// initiate a container
		// construct the objects
		//spring follows eager loading for all the beans
	ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		// using the object
	Bankingservice bs= (Bankingservice)ctx.getBean("service");
	
	System.out.println(bs.calculate(4389));
	
	
	}

}
