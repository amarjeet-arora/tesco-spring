package collectiondemos;

import java.util.HashSet;

public class HashSetApp {

	public static void main(String[] args) {
		 HashSet<String> hs= new  HashSet<String>();
		 
		 hs.add("admin");
		 hs.add("manager");
		 hs.add("qa");
		 hs.add("admin");
		 
		 for(String data: hs) {
			 System.out.println(data);
		 }

	}

}
