package com.restaurant;

public interface Restaurant {
	
	public String prepareFood(String dishName);

}
