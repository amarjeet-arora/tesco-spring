package faltmapdemo;

public class MobileService {
	
	public int getMobileScreenWidth(Mobile mobile) {
		if(mobile != null) {
			DisplayFeatures features= mobile.getDisplayFeatures();
			if(features != null) {
				MobileScreen mobileScreen= features.getMobileScreen();
				if(mobileScreen != null) {
					return mobileScreen.getWidth();
				}
			}
		}
		return 0;
	}

}
