package faltmapdemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class WityhoutFlatMap {
public static void main(String[] args) {
	
	List<String> productList1= Arrays.asList("pro1","pro2","pro3");
	List<String> productList2= Arrays.asList("pro4","pro5","pro6");
    List<String> productList3= Arrays.asList("pro7","pro8","pro9");
	List<String> productList4= Arrays.asList("pro10","pro12","pro13");

	
	List<List<String>> ap= new ArrayList<List<String>>();
	ap.add(productList1);
	ap.add(productList2);
	ap.add(productList3);
	ap.add(productList4);
	
	//List<String> lop= new ArrayList<String>();
	
	/*
	 * for(List<String> pro : ap) { for(String product: pro) { lop.add(product);
	 * System.out.println(lop); //System.out.println(); } }
	 */
	List<String> flatmaplist= ap.stream().flatMap(plist -> plist.stream()).collect(Collectors.toList());
	System.out.println(flatmaplist);
}
}
