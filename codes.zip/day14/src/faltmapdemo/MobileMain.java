package faltmapdemo;

public class MobileMain {

	public static void main(String[] args) {
		 MobileScreen mobileScreen= new MobileScreen(0,1334);
		 DisplayFeatures displayFeatures= new DisplayFeatures("0", mobileScreen);
		 Mobile mobile= new Mobile(45678, "samsung", "78000", displayFeatures);
		 
		 
		 MobileService mobileService= new MobileService();
		 int mWidth= mobileService.getMobileScreenWidth(mobile);
		 System.out.println(mWidth);

	}

}
