package sol;

import java.util.Optional;

public class MobileService {
	
	public int getMobileScreenWidth(Optional<Mobile> mobile) {
		
		return mobile.flatMap(Mobile:: getDisplayFeatures)
				.flatMap(DisplayFeatures::getMobileScreen)
				.map(MobileScreen :: getWidth)
				.orElse(0);
	}
		

}
