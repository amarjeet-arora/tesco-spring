package sol;

import java.util.Optional;

public class DisplayFeatures {
	private String size;
	private Optional<MobileScreen> mobileScreen;
	public DisplayFeatures(String size, Optional<MobileScreen> mobileScreen) {
		super();
		this.size = size;
		this.mobileScreen = mobileScreen;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public Optional<MobileScreen> getMobileScreen() {
		return mobileScreen;
	}
	public void setMobileScreen(Optional<MobileScreen> mobileScreen) {
		this.mobileScreen = mobileScreen;
	}
	
}
