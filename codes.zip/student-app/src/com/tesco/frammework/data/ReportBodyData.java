package com.tesco.frammework.data;

import java.util.ArrayList;

import com.tesco.business.data.Student;

public abstract class ReportBodyData {
	
	public ArrayList<Student> reportData;
	
	public ReportBodyData() {
		 reportData=new ArrayList<Student>();
	}
public abstract void sortData(int sortField,String sortOrder);
}
