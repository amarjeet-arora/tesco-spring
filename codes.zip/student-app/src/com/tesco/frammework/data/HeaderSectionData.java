package com.tesco.frammework.data;

public class HeaderSectionData {
	
	public String title="";

}
