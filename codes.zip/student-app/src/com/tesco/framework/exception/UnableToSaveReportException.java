package com.tesco.framework.exception;

public class UnableToSaveReportException extends Exception{
	
	
public	UnableToSaveReportException() {
	super();
}
public	UnableToSaveReportException(String eid) {
	super(eid);
}
}
