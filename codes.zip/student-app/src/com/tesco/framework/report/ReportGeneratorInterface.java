package com.tesco.framework.report;

import com.tesco.framework.exception.EmptyReportException;
import com.tesco.framework.exception.UnableToSaveReportException;
import com.tesco.frammework.data.FooterSection;
import com.tesco.frammework.data.HeaderSectionData;
import com.tesco.frammework.data.ReportBodyData;

public interface ReportGeneratorInterface {
public void generateReport();
public HeaderSectionData fetchHeader();
public ReportBodyData fetchReportBody() throws EmptyReportException;
public FooterSection fetchFooter();
public void writeDataToFile(HeaderSectionData hdata,ReportBodyData rd,FooterSection fs)throws UnableToSaveReportException;
}
