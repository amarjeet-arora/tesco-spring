package com.tesco.business.rules;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import com.tesco.business.data.Student;
import com.tesco.business.data.StudentData;
import com.tesco.framework.exception.EmptyReportException;
import com.tesco.framework.exception.UnableToSaveReportException;
import com.tesco.framework.report.ReportGeneratorInterface;
import com.tesco.frammework.data.FooterSection;
import com.tesco.frammework.data.HeaderSectionData;
import com.tesco.frammework.data.ReportBodyData;

public class StudentReport  implements ReportGeneratorInterface{

	public static void main(String[] args) {
		StudentReport  report= new StudentReport();
		report.generateReport();
		System.out.println("done");

	}

	@Override
	public void generateReport() {
		 
		try {
		HeaderSectionData hs= fetchHeader();
		FooterSection fs= fetchFooter();
		ReportBodyData rd= fetchReportBody();
		writeDataToFile(hs, rd, fs);
		}catch(Exception e) {}
	}

	@Override
	public HeaderSectionData fetchHeader() {
		HeaderSectionData headerSectionData= new HeaderSectionData();
		headerSectionData.title="R.No\tName\tMaths\tPhysics\tChemistry\tCS\tTotal";
		return headerSectionData;
	}

	@Override
	public ReportBodyData fetchReportBody() throws EmptyReportException {
	 StudentData studentData= new StudentData();
	 int sortField=2;
	 String sortOrder="D";
	 studentData.sortData(sortField, sortOrder);
	 ReportBodyData bodyData= studentData;
	 
		return bodyData;
	}

	@Override
	public FooterSection fetchFooter() {
		FooterSection fs= new FooterSection();
		fs.footerMSG="This is the Student Report....!";
		return fs;
	}

	@Override
	public void writeDataToFile(HeaderSectionData hdata, ReportBodyData rd, FooterSection fs)
			throws UnableToSaveReportException {
		 
		try {
			BufferedWriter br= new BufferedWriter(new FileWriter(new File("student-report.docx")));
			br.write(hdata.title);
			br.write("\n");
			Student s= null;
			ArrayList<Student> list=rd.reportData;
			for(int i=0; i<list.size();i++) {
				s= (Student)list.get(i);
				br.write(s.toString()+ "\n");
			}
			br.write(fs.footerMSG);
			br.close();
		}catch (Exception e) {}
	}

}
