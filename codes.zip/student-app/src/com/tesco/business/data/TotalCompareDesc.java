package com.tesco.business.data;

import java.util.Comparator;

public class TotalCompareDesc implements Comparator<Student> {

	@Override
	public int compare(Student arg0, Student arg1) {

		int t1 = arg0.getMaths() + arg0.getChemistry() + arg0.getPhysics() + arg0.getCs();

		int t2 = arg1.getMaths() + arg1.getChemistry() + arg1.getPhysics() + arg1.getCs();

		if (t1 == t2) {
			return 0;
		} else if (t1 > t2) {
			return -1;
		} else

			return 1;
	}}