package interfacedemo;

public class CooperativeBank implements RBI {

	@Override
	public int checkBalance(String accNo) {
		// TODO Auto-generated method stub
		return 500;
	}

	@Override
	public int depositAmount(int amount) {
		// TODO Auto-generated method stub
		return 400;
	}

	@Override
	public int withdrawAmount(int amount) {
		// TODO Auto-generated method stub
		return 10000;
	}

}
