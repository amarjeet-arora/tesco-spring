package interfacedemo;

public class SBI implements RBI,SEBI{

	@Override
	public void purchaseShare() {
	 System.out.println("share purchased");
		
	}

	@Override
	public void sellShares() {
		 System.out.println("share Sold");

		
	}

	@Override
	public int checkBalance(String accNo) {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public int depositAmount(int amount) {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public int withdrawAmount(int amount) {
		// TODO Auto-generated method stub
		return 300;
	}

}
