package consdemo;

public class AppCons {
	private int empId;
	private String empName;
	private String projectName;
	public AppCons(int empId, String empName, String projectName) {
		 
		this.empId = empId;
		this.empName = empName;
		this.projectName = projectName;
	}
	
	public AppCons() {
		System.out.println("Demo default");
	}

	@Override
	public String toString() {
		return "AppCons [empId=" + empId + ", empName=" + empName + ", projectName=" + projectName + "]";
	}

	 
	

}
