package inter2;

public class AccountManager implements Manager{

	@Override
	public void joinCompany() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takeLeaves() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leadteam() {
		// TODO Auto-generated method stub
		
	}

}
