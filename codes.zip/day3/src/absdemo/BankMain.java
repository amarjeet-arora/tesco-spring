package absdemo;

public class BankMain {
	public static void main(String[] args) {
		BankAbstract abstract1= new AbstractApp();
		
		System.out.println(abstract1.checkBalance("abc3456"));
		
		System.out.println(abstract1.depositAmount(8876));
		
		abstract1.issueCreditCard();
		
	}
	

}
