package absdemo;

public abstract class BankAbstract {
	
	public abstract int checkBalance(String accNo);
	public abstract int depositAmount(int amount);
	public abstract int withdrawAmount(int amount);
	public abstract void  issuePassbook();

    public void issueCreditCard() {
    	System.out.println("card issed by Bank...");
    }
}
