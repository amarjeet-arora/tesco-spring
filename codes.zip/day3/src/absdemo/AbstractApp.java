package absdemo;

public class AbstractApp extends BankAbstract {

	@Override
	public int checkBalance(String accNo) {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public int depositAmount(int amount) {
		// TODO Auto-generated method stub
		return amount+500;
	}

	@Override
	public int withdrawAmount(int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void issuePassbook() {
		// TODO Auto-generated method stub
		
	}

}
