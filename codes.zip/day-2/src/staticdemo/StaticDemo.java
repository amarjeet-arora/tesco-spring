package staticdemo;

public class StaticDemo {
	
	StaticDemo(){
		System.out.println("inside cons");
	}
	
	static int i=10;
	
	static void showData() {
		System.out.println(i);
	}

	static {
		System.out.println("called before main");
	}
	
	
}
