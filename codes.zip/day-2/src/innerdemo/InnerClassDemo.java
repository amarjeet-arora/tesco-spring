package innerdemo;

//outer class
public class InnerClassDemo {
	// creating an array
	private final static int SIZE=15;
	private int[] arrayofData= new int[SIZE];
	
	// initialize the default constructor
	
	public InnerClassDemo() {
		for(int i=0;i<SIZE;i++) {
			arrayofData[i]=i;
		}
	}
	public InnerClassDemo(String name) {
		 System.out.println("Name is "+ name);
	}
	
	
	public void printEven() {
		InnerClass innerClass= new InnerClass();
		while(innerClass.hasNext()) {
			System.out.println(innerClass.getNext());
		}
	}
	
	private class InnerClass{
		private int next=0;
		//check for next value
		public boolean hasNext() {
			return (next <=SIZE -1);
		}
		//stores only even numbers
		public int getNext() {
			int retValue= arrayofData[next];
			next +=2;
			return retValue;
		}
	}

}
