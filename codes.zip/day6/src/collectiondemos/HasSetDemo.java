package collectiondemos;

import java.util.HashSet;

public class HasSetDemo {

	public static void main(String[] args) {
		 
		HashSet<Employee> al= new HashSet<Employee>();
		
		al.add(new Employee(103,"sohan", "delhi"));
		al.add(new Employee(107,"ram", "pune"));
		al.add(new Employee(101,"admin", "mumbai"));
		al.add(new Employee(102,"danis", "chennai"));
		al.add(new Employee(100,"reema", "kolkata"));
		al.add(new Employee(101,"admins", "mumbai"));
		
		for(Employee emp: al) {
			System.out.println(emp);
		}

	}

}
