package collectiondemos;

import java.util.HashMap;

public class HashMapDemo {

	public static void main(String[] args) {
		 
		HashMap<Integer, String> hm= new HashMap<Integer, String>();
		
		hm.put(101, "Pune");
		hm.put(102, "Mumbai");
		hm.put(103, "Indore");
		
		
		for(Integer data: hm.keySet()) {
			System.out.println("key " + data + "Values " +hm.get(data));
		}
		
		 
		

	}

}
