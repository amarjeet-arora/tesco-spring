package collectiondemos;

import java.util.HashSet;
import java.util.TreeSet;

public class TreeSetDemo {
public static void main(String[] args) {
	TreeSet<String> hs= new  TreeSet();
	 
	 hs.add("qa");
	 hs.add("admin");
	 hs.add("manager");
	
	 hs.add("admin");
	 
	 for(String data2: hs) {
		 System.out.println(data2);
	 }

}
}

