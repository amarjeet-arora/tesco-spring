package com.client;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Users;
import com.sf.AppConfig;

public class UpdateUser {
	
	public static void main(String[] args) {
Session session= AppConfig.getSession();
		Transaction tx= session.beginTransaction();
		
		Users user=(Users)session.get(Users.class, 1);
		user.setUserName("Suresh");
		session.update(user);
		tx.commit();
		
	}

}
