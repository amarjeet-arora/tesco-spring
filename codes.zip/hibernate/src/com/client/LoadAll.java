package com.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.entity.Users;
import com.sf.AppConfig;

public class LoadAll {
	
	public static void main(String[] args) {
		 
		Session session= AppConfig.getSession();
		
      Query query= session.createQuery("from Users");
      List<Users> list= query.list();
      System.out.println(list);
	
		
	}

}
