package defaultapp;

public class InterMain {

	public static void main(String[] args) {
		 
		InterfaceOne io= new ImplApp();
		
		io.add();
		//io.show();
		io.show2();
		InterfaceOne.show();

	}

}
