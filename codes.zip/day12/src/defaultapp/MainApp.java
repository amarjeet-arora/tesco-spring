package defaultapp;

public class MainApp implements InterOne,InterTwo{

	@Override
	public void add() {
		System.out.println("body for add");
		
	}

	@Override
	public void show() {
		 
		InterOne.super.show();
		InterTwo.super.show();
	}

}
