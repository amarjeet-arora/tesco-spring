package defaultapp;

public class ImplApp implements InterfaceOne{

	@Override
	public void add() {
		 System.out.println("inside impl class");
		
	}
	
	  @Override
	  public void show2() {
	  System.out.println("demo default-2 impl method"); 
	  add();
	  }
	 
	 // @Override
	  public void show() {
	  System.out.println("demo default-2 impl method"); }
}
