package defaultapp;

@FunctionalInterface
public interface InterfaceOne {
	
	public void add();
	//public void add2();
	public static void show() {
		System.out.println("demo default method");
	}
	public default void show2() {
		System.out.println("demo default method2");
	}

}
