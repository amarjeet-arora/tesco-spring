package streamapp;

import java.util.ArrayList;
import java.util.List;

public class ExternalMain {

	public static void main(String[] args) {
		 List<Integer> al= new ArrayList<Integer>();
		 
		 al.add(12);
		 al.add(20);
		 al.add(8);
		 al.add(11);
		 al.add(3);
		 al.add(2);
		System.out.println( ExternalIterate.streamSum(al));

	}

}
