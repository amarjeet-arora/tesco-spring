package streamapp;

import java.util.Iterator;
import java.util.List;

public class ExternalIterate {
    // external iterator
	public static int countSum(List<Integer> list) {
		int sum=0;
		Iterator<Integer> it= list.iterator();
		while(it.hasNext()) {
			int num= it.next();
			if(num > 10) {
				sum += num;
			}
		}
	return sum;
} // internal iterator
	public static int streamSum(List<Integer> list) {
		
	return list.stream().filter(i -> i > 10).mapToInt(i -> i).sum();
}
	
	
	
	
}
