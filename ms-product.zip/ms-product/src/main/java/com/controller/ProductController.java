package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
@Autowired
	private ProductService productService;
@Value("${product.msg}")
private String msg;

@PostMapping("/addproducts")
public Product addProducts(@RequestBody Product product) {
	
	return productService.addProduct(product);
}
@GetMapping("/getproducts")
public List<Product> loadAll(){
	System.out.println("data from private repo  "+ msg);
	return productService.loadProducts();
}
@GetMapping("/getproducts/{prodlist}")
public List<Product> getPrById(@PathVariable List<Long> prodlist){
	return productService.getProDByIds(prodlist);
}
}
