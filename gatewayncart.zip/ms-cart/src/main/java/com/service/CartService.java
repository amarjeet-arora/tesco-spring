package com.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.dao.CartRepo;
import com.entity.CartEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Product;
import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;

@Service
public class CartService {
	
	@Autowired
	@Qualifier("webclient")
	private WebClient.Builder builder;
	@Autowired
	private CartRepo repo;
	
	public ShoppingCartResponse processAndRequest(Long userId,List<ShoppingCartRequest> shoppingCartRequestsLists) {
		
		// preparing the target URL
		
		ObjectMapper mapper= new ObjectMapper();
		String url="http://ms-product/products/getproducts/"+shoppingCartRequestsLists.stream()
		.map(e -> String.valueOf(e.getProductId())).collect(Collectors.joining(","));
		
		//making rest API call
		
		
		List<Product> productList=builder.build()
				.get()
				.uri(url)
				.retrieve()
				.bodyToFlux(Product.class)
				.collectList()
				.block();
		System.out.println(url);
		System.out.println(productList);
		
		
		// calculate cart total cost
		final Double[] totalCost= {0.0};
		
		productList.forEach(psl -> {
			shoppingCartRequestsLists.forEach(scr -> {
				if(psl.getProductId() == scr.getProductId()) {
					psl.setQuantity((scr.getQuantity()));
					totalCost[0]= totalCost[0] +psl.getAmount()*scr.getQuantity();
					System.out.println(totalCost[0]);
				}
			});
		});
		
		// create cart Entity
		CartEntity cartEntity=null;
		try {
			
			cartEntity= CartEntity.builder()
					.userId(userId)
					.cartId((long)(Math.random()*Math.pow(10,10)))
					.totalItems(productList.size())
					.totalCosts(totalCost[0])
					.products(mapper.writeValueAsString(productList))
					.build();
							
		}catch (Exception e) {}
		
		// save cart to DB
		cartEntity=repo.save(cartEntity);
		
		// return response
		ShoppingCartResponse response= ShoppingCartResponse.builder()
				.cartId(cartEntity.getCartId())
				.userId(cartEntity.getUserId())
				.totalItems(cartEntity.getTotalItems())
				.totalCosts(cartEntity.getTotalCosts())
				.products(productList)
				.build();
		
		return response;
		
		
	}
	

}
