package com.example.photoappdiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoappdiscoveryserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
