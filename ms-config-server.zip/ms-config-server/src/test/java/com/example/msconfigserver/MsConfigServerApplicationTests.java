package com.example.msconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
