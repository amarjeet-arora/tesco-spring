package com.example.msuserclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsUserclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
