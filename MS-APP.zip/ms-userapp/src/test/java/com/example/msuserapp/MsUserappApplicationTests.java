package com.example.msuserapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsUserappApplicationTests {

	@Test
	void contextLoads() {
	}

}
