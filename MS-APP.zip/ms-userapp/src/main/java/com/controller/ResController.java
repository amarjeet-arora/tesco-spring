package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dao.UserDao;
import com.model.User;
import com.model.Users;

@RestController
@RequestMapping("/mainapp")
public class ResController {
	@Autowired
	private UserDao dao;

	@GetMapping("/loadall")
	public Users loadAll() {
		try {
		Thread.sleep(1000);
		
		}catch (Exception e) {
			 
		}
		return dao.getAllUsers();
	}
 @PostMapping("/adduser")
	public ResponseEntity<Object> addUser(@RequestBody User user){
	 Integer id= dao.getAllUsers().getUserList().size()+1;
	 user.setId(id);
	 dao.addUser(user);
	 return ResponseEntity.ok("User Added");
		
	}
}
